#include "../../../includes.h"

// This is an independent project of an individual developer. Dear PVS-Studio, please check it.
// PVS-Studio Static Code Analyzer for C, C++, C#, and Java: http://www.viva64.com

bool available()
{
	if ( g_cl.m_local( ) == nullptr ) {
		return false;
	}

	if ( !g_cl.m_local( ) )
		return false;

	if ( !g_csgo.m_engine->IsInGame( ) )
		return false;

	if ( !g_csgo.m_engine->IsConnected( ) ) {
		return false;
	}

	return true;
}

using PacketStart_t = void(__thiscall*)(void*, int, int);

void __fastcall Hooks::PacketStart(void* ecx, void* edx, int incoming, int outgoing)
{
	static auto original_fn = g_hooks.m_client_state.GetOldMethod< PacketStart_t >( 5 );
	g_cl.m_local((Player*)g_csgo.m_entlist->GetClientEntity(g_csgo.m_engine->GetLocalPlayer()), true);

	if ( available ) {
	 
		if (!g_cl.m_local( )->alive())
			return original_fn(ecx, incoming, outgoing);
   
		if ( g_cl.commands.empty() )
			return original_fn(ecx, incoming, outgoing);

		//if (m_gamerules()->m_bIsValveDS())
		//	return original_fn(ecx, incoming, outgoing);

		for (auto it = g_cl.commands.rbegin(); it != g_cl.commands.rend(); ++it)
		{
			if (!it->is_outgoing)
				continue;

			if (it->command_number == outgoing || outgoing > it->command_number && (!it->is_used || it->previous_command_number == outgoing))
			{
				it->previous_command_number = outgoing;
				it->is_used = true;
				original_fn(ecx, incoming, outgoing);
				break;
			}
		}

		auto result = false;

		for (auto it = g_cl.commands.begin(); it != g_cl.commands.end();)
		{
			if (outgoing == it->command_number || outgoing == it->previous_command_number)
				result = true;

			if (outgoing > it->command_number && outgoing > it->previous_command_number) 
				it = g_cl.commands.erase(it);
			else 
				++it;
		}

		if (!result)
			original_fn(ecx, incoming, outgoing);

	}

	else {
		return original_fn(ecx, incoming, outgoing);
	}
}

using PacketEnd_t = void(__thiscall*)(void*);

void __fastcall Hooks::PacketEnd(void* ecx, void* edx)
{
	static auto original_fn = g_hooks.m_client_state.GetOldMethod<PacketEnd_t>(6);
	g_cl.m_local((Player*)g_csgo.m_entlist->GetClientEntity(g_csgo.m_engine->GetLocalPlayer()), true);

	if (!g_cl.m_local( )->alive())  //-V807
	{
		g_cl.data.clear();
		return original_fn(ecx);
	}

	if (*(int*)((uintptr_t)ecx + 0x164) == *(int*)((uintptr_t)ecx + 0x16C))
	{
		auto ack_cmd = *(int*)((uintptr_t)ecx + 0x4D2C);
		auto correct = std::find_if(g_cl.data.begin(), g_cl.data.end(),
			[&ack_cmd](const correction_data& other_data)
			{
				return other_data.command_number == ack_cmd;
			}
		);

		auto netchannel = g_csgo.m_engine->GetNetChannelInfo();

		if (netchannel && correct != g_cl.data.end())
		{
			if (g_inputpred.m_stored_variables.m_flVelocityModifier > g_cl.m_local( )->m_flVelocityModifier() + 0.1f)
			{
				auto weapon = g_cl.m_weapon;

				if (!weapon || weapon->index( ) != REVOLVER && !weapon->IsGrenade( ))  //-V648
				{
					for (auto& number : g_cl.choked_number)
					{
						auto cmd = &g_csgo.m_input->m_commands[number % MULTIPLAYER_BACKUP];
						auto verified = &g_csgo.m_input->m_verified[number % MULTIPLAYER_BACKUP];

						if (cmd->m_buttons & (IN_ATTACK | IN_ATTACK2))
						{
							cmd->m_buttons &= ~IN_ATTACK;

							verified->m_cmd = *cmd;
							//verified->m_crc = cmd->GetChecksum();
						}
					}
				}
			}

			g_inputpred.m_stored_variables.m_flVelocityModifier = g_cl.m_local( )->m_flVelocityModifier();
		}
	}

	return original_fn(ecx);
}
