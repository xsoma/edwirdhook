#include "../../../includes.h"

void Hooks::DrawModelExecute( uintptr_t ctx, const DrawModelState_t& state, const ModelRenderInfo_t& info, matrix3x4_t* bone ) {
	
	// disable rendering of shadows.
	if( strstr( info.m_model->m_name, XOR( "shadow" ) ) != nullptr )
		return;

	// declarating
	static bool initialized = false;
	static IMaterial* material = nullptr;

	if ( !initialized ) {
		initialized = true;
		material = g_csgo.m_material_system->FindMaterial( " debug/debugambientcube", "Model textures" );
	}

	Player* entity = reinterpret_cast< Player* >( g_csgo.m_entlist->GetClientEntity( info.m_index ) );
	std::string model_name = g_csgo.m_model_info->getModelName( ( model_t* )info.m_model );

	// if we are inGame.
	if ( g_csgo.m_engine->IsInGame( ) && g_cl.m_local( ) ) {

		// if this model is player.
		if ( model_name.find( "models/player" ) != std::string::npos ) {

			// if entity is valid
			if ( entity ) {

				// if entity is player.
				if ( entity->IsPlayer( ) ) {

					// if entity is alive.
					if ( entity->alive( ) ) {

						// if entity is actualy 
						// local player.
						if ( entity->index( ) == g_cl.m_local( )->index( ) && g_csgo.m_input->m_camera_in_third_person ) {

							for ( auto& i : g_cl.m_fake_matrix )
							{
								i[ 0 ][ 3 ] += info.m_origin.x;
								i[ 1 ][ 3 ] += info.m_origin.y;
								i[ 2 ][ 3 ] += info.m_origin.z;
							}

							// get color.
							Color color = g_cfg[XOR("esp_chams_desync_color")].get_color();

							// setting alpha.
							material->AlphaModulate( 0.2f );

							// setting color.
							material->ColorModulate(color);

							// setting flag.
							material->SetFlag(MATERIAL_VAR_IGNOREZ, false);

							// forcing material.
							g_csgo.m_model_render->ForcedMaterialOverride(material);

							g_hooks.m_model_render.GetOldMethod< Hooks::DrawModelExecute_t >(IVModelRender::DRAWMODELEXECUTE)(g_csgo.m_model_render, ctx, state, info, g_cl.m_fake_matrix);

							g_csgo.m_model_render->ForcedMaterialOverride(nullptr);

							for (auto& i : g_cl.m_fake_matrix)
							{
								i[0][3] -= info.m_origin.x;
								i[1][3] -= info.m_origin.y;
								i[2][3] -= info.m_origin.z;
							}

						}

					}

				}
		
			}
		}

	}
	
	// do chams.
	if( g_chams.DrawModel( ctx, state, info, bone ) )
		g_hooks.m_model_render.GetOldMethod< Hooks::DrawModelExecute_t >( IVModelRender::DRAWMODELEXECUTE )( this, ctx, state, info, bone );
}