#pragma once
#include "../../sdk/client.hpp"

class Detours {
public:
	void init( );

public:
	// prototypes.
	static bool __cdecl ReportHit(Hit_t* pHurtInfo);
	static void __cdecl CL_Move(float accumulated_extra_samples, bool bFinalTick);
	static bool __fastcall SetupBones( iclient_renderable* ecx, void* edx, matrix3x4_t* bone_to_world_out, int max_bones, int bone_mask, float curtime );
	static bool __fastcall ShouldSkipAnimation();

	decltype( &ReportHit ) oReportHit;
	decltype( &CL_Move ) oCL_Move;
	decltype( &SetupBones ) oSetupBones;
	//decltype( &ShouldSkipAnimation) oShouldSkipAnimation;
};

extern Detours g_detours;