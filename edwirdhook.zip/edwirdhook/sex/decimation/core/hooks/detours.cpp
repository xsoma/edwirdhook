#include "../../includes.h"

Detours g_detours{ };

void Detours::init( ) {
	// install detours.

	oReportHit = ( decltype( &ReportHit ) )DetourFunction( reinterpret_cast< byte* >( g_csgo.ReportHit ), reinterpret_cast< byte* >( ReportHit ) );

	oCL_Move = (decltype(&CL_Move))DetourFunction(reinterpret_cast<byte*>(g_csgo.CL_Move), reinterpret_cast<byte*>(CL_Move));

	static const auto setup_bones_ad = pattern::find(g_csgo.m_client_dll, XOR("55 8B EC 83 E4 F8 83 EC 18 56 57 8B F9 89 7C 24 0C")) + 0x4E;
	DWORD* pointer = (DWORD*)*(DWORD*)(setup_bones_ad);
	oSetupBones = (decltype(&SetupBones))DetourFunction((PBYTE)pointer[13], (PBYTE)SetupBones);

	static auto shouldskipanimframe = (DWORD)(pattern::find(g_csgo.m_client_dll, XOR( "57 8B F9 8B 07 8B 80 ? ? ? ? FF D0 84 C0 75 02" )));
	DetourFunction((PBYTE)shouldskipanimframe, (PBYTE)ShouldSkipAnimation);
}

bool __fastcall Detours::SetupBones(iclient_renderable* ecx, void* edx, matrix3x4_t* bone_to_world_out, int max_bones, int bone_mask, float curtime)
{
	auto pEnt = reinterpret_cast< Player* >( uintptr_t( ecx ) - 0x4 );

	if ( !pEnt || ! pEnt->IsPlayer( ) )
		return g_detours.oSetupBones( ecx, edx, bone_to_world_out, max_bones, bone_mask, curtime );

	static auto r_jiggle_bones = g_csgo.m_cvar->FindVar( HASH("r_jiggle_bones") );
	auto r_jiggle_bones_backup = r_jiggle_bones->GetInt();

	r_jiggle_bones->SetValue(0);

	if (!ecx)
		return g_detours.oSetupBones( ecx, edx, bone_to_world_out, max_bones, bone_mask, curtime );
	else if ( !g_cfg[XOR("rage_aimbot_enabled")].get<bool>( ) )
		return g_detours.oSetupBones( ecx, edx, bone_to_world_out, max_bones, bone_mask, curtime );
	else
	{

		if (!pEnt->IsPlayer() && !pEnt->alive() && g_cl.m_local())
			return g_detours.oSetupBones( ecx, edx, bone_to_world_out, max_bones, bone_mask, curtime );
		else
		{

			if (pEnt->index() == g_csgo.m_engine->GetLocalPlayer())
			{
				*(int*)((DWORD)pEnt + 0x2698) = 0;
				bone_mask |= 0x200;

				if ( !g_cl.m_allow_bones )
				{
					if ( bone_to_world_out && max_bones != -1 ) {

						if (g_anims.got_matrix)
							memcpy(bone_to_world_out, g_cl.m_real_matrix, sizeof(matrix3x4_t) * max_bones);

					}

					return true;
				}
				else
				{
					if (ecx)
						*reinterpret_cast<int*> (reinterpret_cast<uintptr_t> (ecx) + 0x269C) = 0;

					*reinterpret_cast<float*> (reinterpret_cast<uintptr_t> (pEnt) + 2664) = 0;

					static auto offs_bone_mask = g_netvars.get(HASH("DT_BaseAnimating"), HASH("m_nForceBone")) + 0x20;
					*reinterpret_cast<int*> (reinterpret_cast<uintptr_t> (pEnt) + offs_bone_mask) = 0;
				}

				*(uint32_t*)(uintptr_t(pEnt) + 0xA68) = 0;
			}
			
		}

	}

	pEnt->m_fEffects( ) |= 8;
	pEnt->m_fEffects( ) &= ~8;

	r_jiggle_bones->SetValue( r_jiggle_bones_backup );

	return g_detours.oSetupBones( ecx, edx, bone_to_world_out, max_bones, bone_mask, curtime );


}

bool __fastcall Detours::ShouldSkipAnimation( )
{
	return false;
}