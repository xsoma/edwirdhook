#include "../includes.h"

Resolver g_resolver{ };;

void Resolver::ResolveAngles(Player* player, LagComp::LagRecord_t* record) {
    AimPlayer* data = &g_aimbot.m_players[player->index() - 1];
    CCSGOPlayerAnimState* animstate = player->m_PlayerAnimState();
#define n(yaw) math::NormalizeYaw(fabsf(yaw))
#define delta(angle1, angle2) remainderf(fabsf(angle1 - angle2), 360.0f)

    if (!record->m_bDidShot) {
        if (g_cfg[XOR("cheat_mode")].get<int>() == 1) {
            switch (data->m_missed_shots[player->index()] % 6) {
            case 0:
            case 1:
                record->m_angEyeAngles.x = player->m_angEyeAngles().x = 90.f;
                break;

            case 2:
            case 3:
                record->m_angEyeAngles.x = player->m_angEyeAngles().x = 0.f;
                break;
            case 4:
            case 5:
                record->m_angEyeAngles.x = player->m_angEyeAngles().x = -90.f;
                break;

            default:
                break;
            }
            switch (data->m_missed_shots[player->index()] % 12) {
            case 0:
            case 1:
                record->m_angEyeAngles.y = player->m_angEyeAngles().y = 60.f;
                break;
            case 2:
            case 3:
                record->m_angEyeAngles.y = player->m_angEyeAngles().y = 0.f;
                break;
            case 4:
            case 5:
                record->m_angEyeAngles.y = player->m_angEyeAngles().y = -60.f;
                break;

            case 6:
            case 7:
                record->m_angEyeAngles.y = player->m_angEyeAngles().y = 30.f;
                break;

            case 8:
            case 9:
                record->m_angEyeAngles.y = player->m_angEyeAngles().y = 0.f;
                break;
            case 10:
            case 11:
                record->m_angEyeAngles.y = player->m_angEyeAngles().y = -30.f;
                break;

            default:
                break;
            }

        }

        int resolve_delta = 0.f;

        float eye_yaw = player->m_angEyeAngles().y;
        float lby_yaw = player->m_flLowerBodyYawTarget();
        float desync_delta = delta(eye_yaw, animstate->m_flGoalFeetYaw);

        float fl_left_low_delta = n(lby_yaw - 30.0);
        float fl_right_low_delta = n(lby_yaw + 30.0);

        if (fabs(desync_delta) < 30.f) {
            switch (data->m_missed_shots[player->index()] % 3) {
            case 0: {
                animstate->m_flGoalFeetYaw = backedup_bruteforce[player->index()];
            } break;
            case 1: {
                animstate->m_flGoalFeetYaw = fl_left_low_delta;
                backedup_bruteforce[player->index()] = fl_left_low_delta;
            } break;
            case 2: {
                animstate->m_flGoalFeetYaw = fl_right_low_delta;
                backedup_bruteforce[player->index()] = fl_right_low_delta;
            } break;

            }
        }

        switch (data->m_extending) {

        case 0:
            animstate->m_flGoalFeetYaw = math::NormalizeYaw(player->m_flLowerBodyYawTarget() + 60.f);
            break;
        case 1:
            animstate->m_flGoalFeetYaw = math::NormalizeYaw(player->m_flLowerBodyYawTarget() - 60.f);
            break;
        case 2:
            animstate->m_flGoalFeetYaw = math::NormalizeYaw(player->m_flLowerBodyYawTarget() + 30.f);
            break;
        case 3:
            animstate->m_flGoalFeetYaw = math::NormalizeYaw(player->m_flLowerBodyYawTarget() - 30.f);
            break;
        case 4:
            animstate->m_flGoalFeetYaw = math::NormalizeYaw(player->m_flLowerBodyYawTarget() + 23.f);
            break;
        case 5:
            animstate->m_flGoalFeetYaw = math::NormalizeYaw(player->m_flLowerBodyYawTarget() - 23.f);
            break;

        }

        ResolveStand(data, record);
    }
}

void Resolver::ResolveStand(AimPlayer* data, LagComp::LagRecord_t* record) {
    float max_rotation = record->m_pEntity->GetMaxBodyRotation();

    float resolve_value = 30.f;

    if (!record->m_pState)
        return;

    const auto info = g_anims.GetAnimationInfo(record->m_pEntity);
    if (!info)
        return;

    if (game::IsFakePlayer(record->m_iEntIndex)) {
        return;
    }

    float eye_yaw = record->m_pState->m_flEyeYaw;

    if (max_rotation < resolve_value)
        resolve_value = max_rotation;

    data->m_extending = record->m_pLayers[3].m_cycle == 0.f && record->m_pLayers[3].m_weight == 0.f;
    Player* player;

    auto delta = std::abs(math::NormalizedAngle(eye_yaw - record->m_pState->m_flGoalFeetYaw));
    auto valid_lby = true;

    if (record->m_pState->m_flSpeed > 0.1f || fabs(record->m_pState->m_flSpeedUp) > 100.f)
        valid_lby = record->m_pState->m_flTimeSinceStartedMoving < 0.22f;

    if (fabs(delta) > 30.0f && valid_lby)
    {
        if (data->m_missed_shots[record->m_iEntIndex])
            delta = -delta;

        if (delta > 30.0f) {

            record->m_iWay = 3;
            record->m_iSide = 1;
        }
        else if (delta < -30.0f)
        {
            record->m_iWay = 3;
            record->m_iSide = 2;
        }
    }
    else {

        if (delta > 0) {
            record->m_iWay = 1;
            record->m_iSide = 1;
        }

        else {
            record->m_iWay = 1;
            record->m_iSide = 2;
        }

    }

    if (record->m_iSide == 1) {
        info->m_flBrute = -60.f;
    }

    else if (record->m_iSide == 2) {
        info->m_flBrute = 60.f;
    }

    record->m_pState->m_flGoalFeetYaw = eye_yaw + info->m_flBrute;
}