#include "../includes.h"

void Player::ModifyEyePosition( CCSGOPlayerAnimState* state, vec3_t* pos ) {
	if( !this )
		return;

	// The local player sets up their third-person bones to locate the position of their head,
	// then this position is used to softly bound the vertical camera position for the client.
	if( !state->m_szInHitGroundAnimation && state->m_flDuckAmount == 0 )
		return;

	int nHeadBone = 8;
	if( nHeadBone != -1 ) {
		vec3_t vecHeadPos(
			state->m_baseEntity->m_BoneCache( ).m_pCachedBones[ 8 ][ 0 ][ 3 ],
			state->m_baseEntity->m_BoneCache( ).m_pCachedBones[ 8 ][ 1 ][ 3 ],
			state->m_baseEntity->m_BoneCache( ).m_pCachedBones[ 8 ][ 2 ][ 3 ] );

		vecHeadPos.z += 1.7f;

		// Only correct the eye if the camera is ABOVE the head. If the camera is below the head, that's unlikely
		// to be advantageous for the local player.
		if( vecHeadPos.z < pos->z ) {
			constexpr float FIRSTPERSON_TO_THIRDPERSON_VERTICAL_TOLERANCE_MIN = 4.0f;
			constexpr float FIRSTPERSON_TO_THIRDPERSON_VERTICAL_TOLERANCE_MAX = 10.0f;

			float flLerp = math::SimpleSplineRemapValClamped( abs( pos->z - vecHeadPos.z ),
				FIRSTPERSON_TO_THIRDPERSON_VERTICAL_TOLERANCE_MIN,
				FIRSTPERSON_TO_THIRDPERSON_VERTICAL_TOLERANCE_MAX,
				0.0f, 1.0f );

			pos->z = math::Lerp( flLerp, pos->z, vecHeadPos.z );
		}
	}
}

void Player::attachment_helper( )
{
	using AttachmentHelperFn = void( __thiscall* )( Player*, CStudioHdr* );
	static AttachmentHelperFn DoAttachments = pattern::find( g_csgo.m_client_dll , "55 8B EC 83 EC 48 53 8B 5D 08 89 4D F4" ).as< AttachmentHelperFn >( );
	DoAttachments( this, this->GetModelPtr( ) );
};

C_AnimationLayer* Player::get_animlayers()
{
	return *(C_AnimationLayer**)((DWORD)this + 0x2980);
}

bool Player::setup_bones_fixed(matrix3x4_t* matrix, int mask)
{
	if (!this) //-V704
		return false;

	auto setuped = false;

	auto backup_value = *(uint8_t*)((uintptr_t)this + 0x274);
	*(uint8_t*)((uintptr_t)this + 0x274) = 0;

	auto backup_effects = m_fEffects();
	m_fEffects() |= 8;

	auto animstate = m_PlayerAnimState( );

	auto backup_abs_origin = GetAbsOrigin();

	if (this != g_cl.m_local( ))
		SetAbsOrigin(m_vecOrigin());

	InvalidateBoneCache();

#if RELEASE
	if (mask == BONE_USED_BY_ANYTHING)
		SetupBones(matrix, MAXSTUDIOBONES, mask, m_flSimulationTime());
	else
	{	
		CSetupBones setup_bones;

		setup_bones.m_animating = this;
		setup_bones.m_vecOrigin = m_vecOrigin();
		setup_bones.m_animLayers = get_animlayers();
		setup_bones.m_pHdr = m_pStudioHdr();
		setup_bones.m_nAnimOverlayCount = animlayer_count();
		setup_bones.m_angAngles = Vector(0.0f, animstate ? animstate->m_flGoalFeetYaw : 0.0f, 0.0f);
		setup_bones.m_boneMatrix = matrix;

		memcpy(setup_bones.m_flPoseParameters, &m_flPoseParameter(), 24 * sizeof(float));

		auto weapon = m_hActiveWeapon().Get();
		auto world_model = weapon ? weapon->m_hWeaponWorldModel().Get() : nullptr;

		if (world_model)
			memcpy(setup_bones.m_flWorldPoses, &world_model->m_flPoseParameter(), 24 * sizeof(float));

		setup_bones.m_boneMask = mask;

		Vector position[MAXSTUDIOBONES];
		Quaternion q[MAXSTUDIOBONES];

		setup_bones.m_vecBones = position;
		setup_bones.m_quatBones = q;
		setup_bones.m_flCurtime = m_flSimulationTime();

		setup_bones.setup();

		if (m_CachedBoneData().Base() != m_BoneAccessor().m_pBones)
			memcpy(m_BoneAccessor().m_pBones, setup_bones.m_boneMatrix, m_CachedBoneData().Count() * sizeof(matrix3x4_t));

		setup_bones.fix_bones_rotations();
	}
#else
	SetupBones(matrix, matrix ? 128 : -1, mask, m_flSimulationTime());
#endif

	if ( this != g_cl.m_local( ) )
		SetAbsOrigin(backup_abs_origin);

	m_fEffects() = backup_effects;
	*(uint8_t*)((uintptr_t)this + 0x274) = backup_value;

	return setuped;
}

/*CUtlVector<matrix3x4_t>& Player::GetBoneCache() {
	static auto m_CachedBoneData = *(DWORD*)(pattern::find( g_csgo.m_client_dll, XOR( "FF B7 ?? ?? ?? ?? 52" ) ) + 0x2) + 0x4;
	return *(CUtlVector<matrix3x4_t>*)(uintptr_t(this) + m_CachedBoneData);
}*/