#pragma once

namespace GUI::Controls {
	bool Dropdown( const std::string& name, std::vector< std::string > values, const std::string& var_name );
}
